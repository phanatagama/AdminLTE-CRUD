
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">DATA KOTA</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i> Home</a></li>
              <li class="breadcrumb-item active">Data Kota</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <!-- Main content -->

    <!-- /.content -->
        <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Tabel Data Kota</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <a href="index.php?page=tambah_kota" class="btn btn-primary" role="button" title="Tambah Data"><i class="fas fa-plus"></i> Tambah</a>
                <table id="kota" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Country Code</th>
                    <th>District</th>
                    <th>Population</th>
                    <th>Aksi</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  include "conf/conn.php";
                  $no=0;
                  $result= $mysqli->query("SELECT * FROM city ORDER BY ID DESC");
                  while ($row = $result-> fetch_assoc())
                  {                    
                  ?>

                  <tr>
                    <td><?php echo $no=$no+1;?></td>
                    <td><?php echo $row['Name'];?></td>
                    <td><?php echo $row['CountryCode'];?></td>
                    <td><?php echo $row['District'];?></td>
                    <td><?php echo $row['Population'];?></td>
                    <td>
                      <a href="index.php?page=ubah_kota&id=<?=$row['ID'];?>" class="btn btn-success" role="button" title="Ubah Data"><i class="fas fa-edit"></i></a>
                      <a href="pages/kota/hapus_kota.php?id=<?=$row['ID'];?>" class="btn btn-danger" role="button" title="Hapus Data"><i class="fas fa-trash-alt"></i></a>
                    </td>
                  </tr>

                  <?php } ?>
                  </tbody>
                  
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->

