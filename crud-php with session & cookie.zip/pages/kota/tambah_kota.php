<?php

$nameErr = $countryErr = $districtErr = $popErr = "";
$Name = $CountryCode = $District = $Population = "";
include "conf/conn.php";
if ($_SERVER["REQUEST_METHOD"] == "POST"){
  if (empty($_POST['Name'])){
     $nameErr = "* Name is required";
  } else {
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$_POST['Name'])) {
      $nameErr = "* Only letters and white space allowed"; 
    }else{
      $Name = test_input($_POST["Name"]);
    }
  }
  if (empty($_POST['CountryCode'])) {
    $countryErr = "* Please Choice CountryCode";
  }else{
    if (strlen($_POST['CountryCode'])==3 AND preg_match("/^[a-zA-Z]*$/",$_POST['CountryCode'])){
      $CountryCode = test_input($_POST['CountryCode']);
    }else{
      $countryErr = "* Country must be 3 character and only letters";
    }
  }
  if (empty(trim($_POST['District']))){
    $districtErr = "* District is required";
  } else{
    if (!preg_match("/^[a-zA-Z0-9 ]*$/",$_POST['District'])) {
      $districtErr = "* Only letters or number and white space allowed"; 
    }else{
      $District = test_input($_POST['District']);
    }
  }
  if (empty($_POST['Population'])){
    $popErr = "* Population is required";
  }else{
    if (is_numeric($_POST['Population'])){
      $Population = test_input($_POST['Population']);
    }else{
      $popErr = "* Must be Number";
    }
  }
  if ($Name !== "" && $CountryCode !== "" && $District !=="" && $Population !== "" ){
    $query = ("INSERT INTO city (Name,CountryCode,District,Population) VALUES ('".$Name."','".$CountryCode."','".$District."','".$Population."')");
    if(!($mysqli->query($query))){
      die(mysqli_error($mysqli));
    }else{
      echo '<script>alert("Data Berhasil Ditambahkan !!!");
      window.location.href="index.php?page=data_kota"</script>';
    }
  }
} 
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">TAMBAH KOTA</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="http://d.pbw.ilkom.unej.ac.id/192410102029"><i class="fas fa-home"></i> Home</a></li>
              <li class="breadcrumb-item active">Tambah Kota</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" action="index.php?page=tambah_kota">
              <div class="box-body">
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="Name" class="form-control" placeholder="Name" value="<?= (empty($Name)) ? '' : $Name ?>" required>
                  <span class="error"><?= $nameErr;?></span>
                </div>

                <div class="form-group">
                  <label for="exampleSelectRounded0">CountryCode</label>
                  <select class="custom-select rounded-0" id="exampleSelectRounded0" name="CountryCode">
                  <?php
                    $result= $mysqli->query("SELECT distinct(CountryCode) FROM city ORDER BY CountryCode");
                    while ($row = $result-> fetch_assoc())
                    {                    
                    ?>
                    <option <?= ($CountryCode == $row['CountryCode']) ? 'selected="selected"' : '' ?> value="<?= $row['CountryCode']; ?>"><?= $row['CountryCode']; ?></option>
                  <?php } ?>
                  </select>
                  <span class="error"><?= $countryErr;?></span>
                </div>
                <div class="form-group">
                  <label>District</label>
                  <input type="text" name="District" class="form-control" placeholder="District" value="<?= (empty($District)) ? '' : $District ?>" required>
                  <span class="error"><?= $districtErr;?></span>
                </div>
                <div class="form-group">
                  <label>Population</label>
                  <input type="number" name="Population" class="form-control" placeholder="Population" value="<?= (empty($Population)) ? '' : $Population ?>" required>
                  <span class="error"><?= $popErr;?></span>
                </div>

              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary" title="Simpan Data"> <i class="fas fa-save"></i> Simpan</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->