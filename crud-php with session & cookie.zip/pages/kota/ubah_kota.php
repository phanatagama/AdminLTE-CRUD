<?php

$nameErr = $countryErr = $districtErr = $popErr = "";
$Name = $CountryCode = $District = $Population = "";
if ($_SERVER["REQUEST_METHOD"] == "POST"){
  include "conf/conn.php";
  $id = $_POST['id'];
  if (empty($_POST['Name'])){
     $nameErr = "* Name is required";
  } else {
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$_POST['Name'])) {
      $nameErr = "* Only letters and white space allowed"; 
    }else{
      $Name = test_input($_POST["Name"]);
    }
  }
  if (empty($_POST['CountryCode'])) {
    $countryErr = "* Please Choice CountryCode";
  }else{
    if (strlen($_POST['CountryCode'])==3 AND preg_match("/^[a-zA-Z]*$/",$_POST['CountryCode'])){
      $CountryCode = test_input($_POST['CountryCode']);
    }else{
      $countryErr = "* Country must be 3 character and only letters";
    }
  }
  if (empty(trim($_POST['District']))){
    $districtErr = "* District is required";
  } else{
    if (!preg_match("/^[a-zA-Z0-9 ]*$/",$_POST['District'])) {
      $districtErr = "* Only letters or number and white space allowed"; 
    }else{
      $District = test_input($_POST['District']);
    }
  }
  if (empty($_POST['Population'])){
    $popErr = "* Population is required";
  }else{
    if (is_numeric($_POST['Population'])){
      $Population = test_input($_POST['Population']);
    }else{
      $popErr = "* Must be Number";
    }
  }
  if ($Name !== "" && $CountryCode !== "" && $District !=="" && $Population !== "" ){
    $query = ("UPDATE city SET Name='$Name',CountryCode='$CountryCode',District='$District',Population='$Population' WHERE ID='$id'");
    if(!($mysqli->query($query))){
      die(mysqli_error($mysqli));
    }else{
      echo '<script>alert("Data Berhasil Diubah !!!");
      window.location.href="index.php?page=data_kota"</script>';
    }
  }
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
if (isset($_GET['id'])){
  $id = $_GET['id'];
}
$result = $mysqli->query("SELECT * FROM city WHERE ID='".$id."'");
$row = $result->fetch_assoc();
?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">UBAH KOTA</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="http://d.pbw.ilkom.unej.ac.id/192410102029"><i class="fas fa-home"></i> Home</a></li>
              <li class="breadcrumb-item active">Ubah Kota</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" action="index.php?page=ubah_kota">
              <div class="box-body">
                <input type="hidden" name="id" value="<?= $row['ID']; ?>">
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="Name" class="form-control" placeholder="Name" value="<?= (empty($Name)) ? $row['Name'] : $Name ?>" required><span class="error"><?= $nameErr;?></span>
                </div>
                <div class="form-group">
                  <label for="exampleSelectRounded0">CountryCode</label>
                  <select class="custom-select rounded-0" id="exampleSelectRounded0" name="CountryCode">
                  <?php
                    $result2= $mysqli->query("SELECT distinct(CountryCode) FROM city ORDER BY CountryCode");
                    while ($row2 = $result2-> fetch_assoc())
                    {                    
                    ?>
                    <option <?= ($row['CountryCode'] == $row2['CountryCode']) ? 'selected="selected"' : '' ?> value="<?= $row2['CountryCode']; ?>"><?= $row2['CountryCode']; ?></option>
                  <?php } ?>
                  </select>
                  <span class="error"><?= $countryErr;?></span>
                </div>
                <div class="form-group">
                  <label>District</label>
                  <input type="text" name="District" class="form-control" placeholder="District" value="<?= (empty($District)) ? $row['District'] : $District ?>" required>
                  <span class="error"><?= $districtErr;?></span>
                </div>
                <div class="form-group">
                  <label>Population</label>
                  <input type="number" name="Population" class="form-control" placeholder="Population" value="<?= (empty($Population)) ? $row['Population'] : $Population ?>" required>
                  <span class="error"><?= $popErr;?></span>
                </div>

              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary" title="Simpan Data"> <i class="fas fa-save"></i> Simpan</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->