<?php
session_start();
if (!(isset($_SESSION["login"]))){
  header("Location: login.php");
  exit();
}

include "../../conf/conn.php";
$id = $_GET['id'];
$query = ("DELETE FROM city WHERE ID ='".$id."'");

if(!(mysqli_query($mysqli,$query))){
	die(mysqli_error($mysqli));
}else{echo '<script>alert("Data Berhasil Dihapus !!!");window.location.href="../../index.php?page=data_kota"</script>';
}
?>