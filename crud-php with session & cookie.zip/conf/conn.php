<?php
$mysqli = new mysqli("localhost","root","","uts192410102029");
// mysqli_connect('localhost','root','') or die('Connect Failed !!!');
// mysqli_select_db('perusahaan') or die('Database Not Found !!!');
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}

?>