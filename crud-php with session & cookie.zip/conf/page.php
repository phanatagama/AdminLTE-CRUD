<?php
if(isset($_GET['page'])){
  $page = $_GET['page'];
  switch ($page) {// Beranda
	  case 'data_kota':
	    include 'pages/kota/data_kota.php';
	    break;
	  case 'tambah_kota':
	    include 'pages/kota/tambah_kota.php';
	    break;
	  case 'ubah_kota':
		include 'pages/kota/ubah_kota.php';
		break;
  }
}else{
    include "pages/kota/data_kota.php";
  }
?>