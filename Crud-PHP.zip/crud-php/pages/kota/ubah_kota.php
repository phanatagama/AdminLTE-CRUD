<?php
if($_POST){
  include "../../conf/conn.php";
  $id = $_POST['id'];
  $Name = $_POST['Name'];
  $CountryCode = $_POST['CountryCode'];
  $District = $_POST['District'];
  $Population = $_POST['Population'];
  $query = ("UPDATE city SET Name='$Name',CountryCode='$CountryCode',District='$District',Population='$Population' WHERE ID='$id'");
  if(!($mysqli->query($query))){
    die(mysql_error);
  }else{
    echo '<script>alert("Data Berhasil Diubah !!!");
    window.location.href="../../index.php?page=data_kota"</script>';
  }
}

$result = $mysqli->query("SELECT * FROM city WHERE ID='".$_GET['id']."'");
$row = $result->fetch_assoc();
?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">UBAH KOTA</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i> Home</a></li>
              <li class="breadcrumb-item active">Ubah Kota</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" action="pages/kota/ubah_kota.php">
              <div class="box-body">
                <input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="Name" class="form-control" placeholder="Name" value="<?php echo $row['Name']; ?>" required>
                </div>
                <div class="form-group">
                  <label>CountryCode</label>
                  <input type="text" name="CountryCode" class="form-control" placeholder="CountryCode" value="<?php echo $row['CountryCode']; ?>" required>
                </div>
                <div class="form-group">
                  <label>District</label>
                  <input type="text" name="District" class="form-control" placeholder="District" value="<?php echo $row['District']; ?>" required>
                </div>
                <div class="form-group">
                  <label>Population</label>
                  <input type="number" name="Population" class="form-control" placeholder="Population" value="<?php echo $row['Population']; ?>" required>
                </div>

              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary" title="Simpan Data"> <i class="fas fa-save"></i> Simpan</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->