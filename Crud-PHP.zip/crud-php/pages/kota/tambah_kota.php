<?php 
if($_POST){
  include "../../conf/conn.php";
  $Name = $_POST['Name'];
  $CountryCode = $_POST['CountryCode'];
  $District = $_POST['District'];
  $Population = $_POST['Population'];
  $query = ("INSERT INTO city(ID,Name,CountryCode,District,Population) VALUES ('','".$Name."','".$CountryCode."','".$District."','".$Population."')");
  if(!($mysqli->query($query))){
    die(mysql_error);
  }else{
    echo '<script>alert("Data Berhasil Ditambahkan !!!");
    window.location.href="../../index.php?page=data_kota"</script>';
  }
}
?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">TAMBAH KOTA</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i> Home</a></li>
              <li class="breadcrumb-item active">Tambah Kota</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" action="pages/kota/tambah_kota.php">
              <div class="box-body">
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="Name" class="form-control" placeholder="Name" required>
                </div>
                <div class="form-group">
                  <label>CountryCode</label>
                  <input type="text" name="CountryCode" class="form-control" placeholder="CountryCode" required>
                </div>
                <div class="form-group">
                  <label>District</label>
                  <input type="text" name="District" class="form-control" placeholder="District" required>
                </div>
                <div class="form-group">
                  <label>Population</label>
                  <input type="number" name="Population" class="form-control" placeholder="Population" required>
                </div>

              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary" title="Simpan Data"> <i class="fas fa-save"></i> Simpan</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->